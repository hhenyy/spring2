package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Mysqlboard03Application {

	public static void main(String[] args) {
		SpringApplication.run(Mysqlboard03Application.class, args);
	}

}
